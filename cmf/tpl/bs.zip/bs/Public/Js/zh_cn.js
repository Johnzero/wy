<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>�������</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<META http-equiv=refresh content=5;url=http://www.ruifox.com/>
<STYLE type=text/css>BODY {
	MARGIN: 0px; BACKGROUND-COLOR: #000000
}
BODY {
	COLOR: #ffffff; FONT-FAMILY: Comic Sans MS
}
TD {
	COLOR: #ffffff; FONT-FAMILY: Comic Sans MS
}
TH {
	COLOR: #ffffff; FONT-FAMILY: Comic Sans MS
}
.style6 {
	FONT-WEIGHT: bold; FONT-SIZE: 12px
}
.style7 {
	FONT-SIZE: 18px
}
.style8 {
	FONT-SIZE: 12px
}
.style9 {
	FONT-SIZE: 24px; FONT-FAMILY: "����_GB2312"
}
.style9 a{
	FONT-SIZE: 24px; FONT-FAMILY: "����_GB2312"; color:#FFFFFF; text-decoration:none;
}
.style10 {
	COLOR: #ff0000
}
</STYLE>

<META content="MSHTML 6.00.2900.3354" name=GENERATOR></HEAD>
<BODY>
<DIV align=center>
<P align=left>�� 
<P>��</P>
<P>��</P>
<P align=center>��<a href="http://www.ruifox.com/"><IMG 
src="404.gif" width=176 height=220 border="0" 
tppabs="404.gif"></a></P>
<P><B><FONT face=���� size=5>��ҳ.<FONT 
color=#ff0000>��.</FONT>��</FONT></B></P></DIV>
<DIV class=style6 align=center>
<P class=style7>��</P>
<!-- <P class=style8>www.LeadTo.com.cn</P> -->
<P class=style9><SPAN class=style10>����</SPAN>.����.<!-- <a href="http://www.yxbt.com/" target="_blank">��Щ��ͬ��Ӱ</a> --><SPAN 
class=style10>��ҳ</SPAN></P>
<P>��</P></DIV>

</BODY></HTML>
